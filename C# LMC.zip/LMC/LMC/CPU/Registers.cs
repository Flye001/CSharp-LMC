﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LMC
{
	public class Registers
	{
		public int MDR { get; set; }
		public int MAR { get; set; }
		public int PC { get; set; }
		public int ACC { get; set; }
		public int CIR { get; set; }
	}
}
